﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Quanliphongtro
{
    public partial class frmLogin : Form
    {
        private DataServices myDataServices;

        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            // kết nối vs csdl
            myDataServices = new DataServices();
            if (myDataServices.OpenDB() == false) return;
            // kiểm tra UserName và Password trong bảng Users
            string sSql = "SELECT * fROM tblTaiKhoan WHERE (TaiKhoan = N'" + txtTaiKhoan.Text + "') and (MatKhau = N'" + txtMatKhau.Text + "')";
            DataTable dtQuanLy = myDataServices.RunQuery(sSql);
            if (dtQuanLy.Rows.Count == 0)
            {
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu sai!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTaiKhoan.Focus();
                return;
            }
            else
            {
                frmMain frmMain = new frmMain();
                this.Hide();
                frmMain.ShowDialog();
                this.Close();
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }  
        private void chkShow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShow.Checked)
            {
                txtMatKhau.UseSystemPasswordChar = false;
            }
            else
            {
                txtMatKhau.UseSystemPasswordChar = true;
            }
        }

        private void txtTaiKhoan_MouseClick(object sender, MouseEventArgs e)
        {
            txtTaiKhoan.SelectAll();
        }

        private void txtMatKhau_MouseClick(object sender, MouseEventArgs e)
        {
            txtMatKhau.SelectAll();
        }
    }
}
