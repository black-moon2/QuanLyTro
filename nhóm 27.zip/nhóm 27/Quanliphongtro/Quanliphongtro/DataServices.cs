﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//mở thêm các thư viện
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace Quanliphongtro
{
    class DataServices
    {
        private static SqlConnection mySqlConnection;
        private SqlDataAdapter myDataAdapter;
        public bool OpenDB()
        {
            // kết nối csdl
            string conStr = @"Data Source=DESKTOP-F3NVSE6\SQLEXPRESS;Initial Catalog=QLPhongTro;Integrated Security=True";
            try
            {
                mySqlConnection = new SqlConnection(conStr);
                mySqlConnection.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Error " + ex.Number.ToString());
                mySqlConnection = null;
                return false;
            }
            return true;
        }
        public DataTable RunQuery(string sSql)
        {
            DataTable myDataTable = new DataTable();
            myDataAdapter = new SqlDataAdapter();
            try
            {
                // cập nhật dữ liệu
                myDataAdapter = new SqlDataAdapter(sSql, mySqlConnection);
                SqlCommandBuilder mySqlCommandBuilder = new SqlCommandBuilder(myDataAdapter);
                myDataAdapter.Fill(myDataTable);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Error " + ex.Number.ToString());
                return null;
            }
            return myDataTable;
        }
        public void Update(DataTable myDataTable)
        {
            try
            {
                // truy van và cập nhật du lieu
                myDataAdapter.Update(myDataTable);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Error " + ex.Number.ToString());
            }
        }
        // thực hiện một lệnh INSERT, UPDATE, DELETE hoặc một thủ tục không trả về kết quả
        public void ExecuteNonQuery(string sSql)
        {
            SqlCommand mySqlCommand = new SqlCommand(sSql, mySqlConnection);
            try
            {
                mySqlCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Error " + ex.Number.ToString());
            }
        }
    }
}
