﻿using System;
using Quanliphongtro.Main_Detail;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanliphongtro
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private void AddForm(Form f)
        {
            f.MdiParent = this;
            f.Show();
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

 
        private void phòngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var f = new frmPhong();
            AddForm(f);
        }

        private void thanhToanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var f = new frmThanhToan();
            AddForm(f);
        }

        private void tsmKhachHang_Click(object sender, EventArgs e)
        {
            var f = new frmKH();
            AddForm(f);
        }

        private void tsmHopDongCT_Click(object sender, EventArgs e)
        {
            var f = new frmChiTietHD();
            AddForm(f);
        }

        private void tsmViewHopDong_Click(object sender, EventArgs e)
        {
            var f = new frmViewHopDong();
            AddForm(f);
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void doanhThuToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var f = new frmDoanhThu();
            AddForm(f);
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }
    }
}
