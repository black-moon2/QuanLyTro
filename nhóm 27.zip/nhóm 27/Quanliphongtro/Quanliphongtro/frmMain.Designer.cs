﻿namespace Quanliphongtro
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStripQL = new System.Windows.Forms.MenuStrip();
            this.hệThóngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cấuHìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmKhachHang = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmViewHopDong = new System.Windows.Forms.ToolStripMenuItem();
            this.tácVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmHopDongCT = new System.Windows.Forms.ToolStripMenuItem();
            this.thanhToanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.doanhThuToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.liênHệToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phiênBảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripQL.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripQL
            // 
            this.menuStripQL.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.menuStripQL.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStripQL.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStripQL.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStripQL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThóngToolStripMenuItem,
            this.danhMụcToolStripMenuItem,
            this.tácVụToolStripMenuItem,
            this.thôngTinToolStripMenuItem});
            this.menuStripQL.Location = new System.Drawing.Point(0, 0);
            this.menuStripQL.Name = "menuStripQL";
            this.menuStripQL.Size = new System.Drawing.Size(1062, 38);
            this.menuStripQL.TabIndex = 0;
            this.menuStripQL.Text = "menuStrip";
            // 
            // hệThóngToolStripMenuItem
            // 
            this.hệThóngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cấuHìnhToolStripMenuItem,
            this.toolStripSeparator1,
            this.thoátToolStripMenuItem});
            this.hệThóngToolStripMenuItem.Name = "hệThóngToolStripMenuItem";
            this.hệThóngToolStripMenuItem.Size = new System.Drawing.Size(130, 34);
            this.hệThóngToolStripMenuItem.Text = "Hệ Thống";
            // 
            // cấuHìnhToolStripMenuItem
            // 
            this.cấuHìnhToolStripMenuItem.Name = "cấuHìnhToolStripMenuItem";
            this.cấuHìnhToolStripMenuItem.Size = new System.Drawing.Size(210, 38);
            this.cấuHìnhToolStripMenuItem.Text = "Cấu Hình";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(207, 6);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(210, 38);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // danhMụcToolStripMenuItem
            // 
            this.danhMụcToolStripMenuItem.Checked = true;
            this.danhMụcToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.danhMụcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.phòngToolStripMenuItem,
            this.tsmKhachHang,
            this.tsmViewHopDong});
            this.danhMụcToolStripMenuItem.Name = "danhMụcToolStripMenuItem";
            this.danhMụcToolStripMenuItem.Size = new System.Drawing.Size(134, 34);
            this.danhMụcToolStripMenuItem.Text = "Danh Mục";
            // 
            // phòngToolStripMenuItem
            // 
            this.phòngToolStripMenuItem.Name = "phòngToolStripMenuItem";
            this.phòngToolStripMenuItem.Size = new System.Drawing.Size(275, 38);
            this.phòngToolStripMenuItem.Text = "Phòng";
            this.phòngToolStripMenuItem.Click += new System.EventHandler(this.phòngToolStripMenuItem_Click);
            // 
            // tsmKhachHang
            // 
            this.tsmKhachHang.Name = "tsmKhachHang";
            this.tsmKhachHang.Size = new System.Drawing.Size(275, 38);
            this.tsmKhachHang.Text = "Khách Hàng";
            this.tsmKhachHang.Click += new System.EventHandler(this.tsmKhachHang_Click);
            // 
            // tsmViewHopDong
            // 
            this.tsmViewHopDong.Name = "tsmViewHopDong";
            this.tsmViewHopDong.Size = new System.Drawing.Size(275, 38);
            this.tsmViewHopDong.Text = "Xem Hợp Đồng";
            this.tsmViewHopDong.Click += new System.EventHandler(this.tsmViewHopDong_Click);
            // 
            // tácVụToolStripMenuItem
            // 
            this.tácVụToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmHopDongCT,
            this.thanhToanToolStripMenuItem,
            this.toolStripSeparator3,
            this.doanhThuToolStripMenuItem1});
            this.tácVụToolStripMenuItem.Name = "tácVụToolStripMenuItem";
            this.tácVụToolStripMenuItem.Size = new System.Drawing.Size(97, 34);
            this.tácVụToolStripMenuItem.Text = "Tác Vụ";
            // 
            // tsmHopDongCT
            // 
            this.tsmHopDongCT.Name = "tsmHopDongCT";
            this.tsmHopDongCT.Size = new System.Drawing.Size(308, 38);
            this.tsmHopDongCT.Text = "Hợp Đồng Chi Tiết";
            this.tsmHopDongCT.Click += new System.EventHandler(this.tsmHopDongCT_Click);
            // 
            // thanhToanToolStripMenuItem
            // 
            this.thanhToanToolStripMenuItem.Name = "thanhToanToolStripMenuItem";
            this.thanhToanToolStripMenuItem.Size = new System.Drawing.Size(308, 38);
            this.thanhToanToolStripMenuItem.Text = "Thanh Toán";
            this.thanhToanToolStripMenuItem.Click += new System.EventHandler(this.thanhToanToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(305, 6);
            // 
            // doanhThuToolStripMenuItem1
            // 
            this.doanhThuToolStripMenuItem1.Name = "doanhThuToolStripMenuItem1";
            this.doanhThuToolStripMenuItem1.Size = new System.Drawing.Size(308, 38);
            this.doanhThuToolStripMenuItem1.Text = "Doanh Thu";
            this.doanhThuToolStripMenuItem1.Click += new System.EventHandler(this.doanhThuToolStripMenuItem1_Click);
            // 
            // thôngTinToolStripMenuItem
            // 
            this.thôngTinToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.liênHệToolStripMenuItem,
            this.phiênBảnToolStripMenuItem});
            this.thôngTinToolStripMenuItem.Name = "thôngTinToolStripMenuItem";
            this.thôngTinToolStripMenuItem.Size = new System.Drawing.Size(133, 34);
            this.thôngTinToolStripMenuItem.Text = "Thông Tin";
            // 
            // liênHệToolStripMenuItem
            // 
            this.liênHệToolStripMenuItem.Name = "liênHệToolStripMenuItem";
            this.liênHệToolStripMenuItem.Size = new System.Drawing.Size(219, 38);
            this.liênHệToolStripMenuItem.Text = "Liên Hệ";
            // 
            // phiênBảnToolStripMenuItem
            // 
            this.phiênBảnToolStripMenuItem.Name = "phiênBảnToolStripMenuItem";
            this.phiênBảnToolStripMenuItem.Size = new System.Drawing.Size(219, 38);
            this.phiênBảnToolStripMenuItem.Text = "Phiên Bản";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1062, 627);
            this.Controls.Add(this.menuStripQL);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStripQL;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lí Phòng Trọ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStripQL.ResumeLayout(false);
            this.menuStripQL.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripQL;
        private System.Windows.Forms.ToolStripMenuItem hệThóngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cấuHìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmKhachHang;
        private System.Windows.Forms.ToolStripMenuItem tácVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmHopDongCT;
        private System.Windows.Forms.ToolStripMenuItem thôngTinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem liênHệToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phiênBảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thanhToanToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem doanhThuToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsmViewHopDong;
    }
}

