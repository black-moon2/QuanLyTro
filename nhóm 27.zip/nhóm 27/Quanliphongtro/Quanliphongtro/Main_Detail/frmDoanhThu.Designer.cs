﻿namespace Quanliphongtro.Main_Detail
{
    partial class frmDoanhThu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNgayKetThuc = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtNgayBatDau = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lbTienPhong = new System.Windows.Forms.Label();
            this.lbTienMang = new System.Windows.Forms.Label();
            this.lbTienNuoc = new System.Windows.Forms.Label();
            this.lbTienDien = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbTongTien = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNgayKetThuc
            // 
            this.txtNgayKetThuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgayKetThuc.Location = new System.Drawing.Point(520, 34);
            this.txtNgayKetThuc.Name = "txtNgayKetThuc";
            this.txtNgayKetThuc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtNgayKetThuc.Size = new System.Drawing.Size(172, 30);
            this.txtNgayKetThuc.TabIndex = 140;
            this.txtNgayKetThuc.Text = "2022-06-19";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(353, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(143, 25);
            this.label10.TabIndex = 142;
            this.label10.Text = "Ngày Kết Thúc";
            // 
            // txtNgayBatDau
            // 
            this.txtNgayBatDau.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgayBatDau.Location = new System.Drawing.Point(151, 34);
            this.txtNgayBatDau.Name = "txtNgayBatDau";
            this.txtNgayBatDau.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtNgayBatDau.Size = new System.Drawing.Size(166, 30);
            this.txtNgayBatDau.TabIndex = 139;
            this.txtNgayBatDau.Text = "2022-05-19";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 25);
            this.label4.TabIndex = 141;
            this.label4.Text = "Ngày Bắt Đầu ";
            // 
            // btnThongKe
            // 
            this.btnThongKe.Location = new System.Drawing.Point(113, 87);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(88, 55);
            this.btnThongKe.TabIndex = 143;
            this.btnThongKe.Text = "Thống Kê";
            this.btnThongKe.UseVisualStyleBackColor = true;
            this.btnThongKe.Click += new System.EventHandler(this.btnTongKet_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 20);
            this.label2.TabIndex = 144;
            this.label2.Text = "Tổng Tiền Phòng :";
            // 
            // lbTienPhong
            // 
            this.lbTienPhong.AutoSize = true;
            this.lbTienPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTienPhong.Location = new System.Drawing.Point(279, 170);
            this.lbTienPhong.Name = "lbTienPhong";
            this.lbTienPhong.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbTienPhong.Size = new System.Drawing.Size(19, 20);
            this.lbTienPhong.TabIndex = 145;
            this.lbTienPhong.Text = "0";
            this.lbTienPhong.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTienMang
            // 
            this.lbTienMang.AutoSize = true;
            this.lbTienMang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTienMang.Location = new System.Drawing.Point(279, 244);
            this.lbTienMang.Name = "lbTienMang";
            this.lbTienMang.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbTienMang.Size = new System.Drawing.Size(19, 20);
            this.lbTienMang.TabIndex = 152;
            this.lbTienMang.Text = "0";
            this.lbTienMang.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTienNuoc
            // 
            this.lbTienNuoc.AutoSize = true;
            this.lbTienNuoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTienNuoc.Location = new System.Drawing.Point(673, 244);
            this.lbTienNuoc.Name = "lbTienNuoc";
            this.lbTienNuoc.Size = new System.Drawing.Size(19, 20);
            this.lbTienNuoc.TabIndex = 151;
            this.lbTienNuoc.Text = "0";
            this.lbTienNuoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTienDien
            // 
            this.lbTienDien.AutoSize = true;
            this.lbTienDien.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTienDien.Location = new System.Drawing.Point(673, 170);
            this.lbTienDien.Name = "lbTienDien";
            this.lbTienDien.Size = new System.Drawing.Size(19, 20);
            this.lbTienDien.TabIndex = 150;
            this.lbTienDien.Text = "0";
            this.lbTienDien.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 20);
            this.label1.TabIndex = 149;
            this.label1.Text = "Tổng Tiền Mạng :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(415, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 20);
            this.label5.TabIndex = 148;
            this.label5.Text = "Tổng Tiền Nước :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(415, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 20);
            this.label6.TabIndex = 147;
            this.label6.Text = "Tổng Tiền Điện :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(83, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 20);
            this.label3.TabIndex = 153;
            this.label3.Text = "Tổng Tiền Tất Cả :";
            // 
            // lbTongTien
            // 
            this.lbTongTien.AutoSize = true;
            this.lbTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTongTien.Location = new System.Drawing.Point(354, 325);
            this.lbTongTien.Name = "lbTongTien";
            this.lbTongTien.Size = new System.Drawing.Size(19, 20);
            this.lbTongTien.TabIndex = 154;
            this.lbTongTien.Text = "0";
            this.lbTongTien.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmDoanhThu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(821, 477);
            this.Controls.Add(this.lbTongTien);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbTienMang);
            this.Controls.Add(this.lbTienNuoc);
            this.Controls.Add(this.lbTienDien);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbTienPhong);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnThongKe);
            this.Controls.Add(this.txtNgayKetThuc);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtNgayBatDau);
            this.Controls.Add(this.label4);
            this.Name = "frmDoanhThu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Doanh Thu";
            this.Load += new System.EventHandler(this.frmDoanhThu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNgayKetThuc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNgayBatDau;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbTienPhong;
        private System.Windows.Forms.Label lbTienMang;
        private System.Windows.Forms.Label lbTienNuoc;
        private System.Windows.Forms.Label lbTienDien;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbTongTien;
    }
}