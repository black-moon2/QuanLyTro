﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanliphongtro.Main_Detail
{
    public partial class frmViewHopDong : Form
    {
        DataTable dtKhach;
        DataTable dtPhong;
        //khai báo đối tượng lớp dịch vụ dữ liệu
        private DataServices myDataServices;
        //khai báo biến để lưu bản sao của bảng dữ liệu tblHopDong
        private DataTable dtHopDong;
        //khai báo biến để kiểm tra đã chọn nút thêm mới hay sửa
        private bool modeNew;

        public frmViewHopDong()
        {
            InitializeComponent();
        }
        private void LayDuLieuPhong()
        {
            string sSql = "Select * from tblPhong order by TenPhong";
            dtPhong = myDataServices.RunQuery(sSql);
            cboTenPhong.DataSource = dtPhong;
            cboTenPhong.DisplayMember = "TenPhong";
            cboTenPhong.ValueMember = "IDPhong";
        }
        private void LayDuLieuKhach()
        {
            string sSql = "Select * from tblNguoiDung";
            dtKhach = myDataServices.RunQuery(sSql);
            cboSoDT.DataSource = dtKhach;
            cboSoDT.DisplayMember = "DienThoai";
            cboSoDT.ValueMember = "IDKhachHang";
        }
        private void ViewHopDong_Load(object sender, EventArgs e)
        {
            myDataServices = new DataServices();
            //1. chuyển dữ liệu vào cboTenPhong
            LayDuLieuPhong();
            //
            LayDuLieuKhach();
            //thiết lập các điều khiển
            SetControls(false);
            //Hiển thị dữ liệu
            Display();
            //Chú ý từ đây về sau không dùng myDataService() cho bảng khác

        }
        //hàm truy vấn dữ liệu
        private void Display()
        {
            string sSql = "SELECT * FROM tblHopDong Order By IDHopDong";
            myDataServices = new DataServices();
            dtHopDong = myDataServices.RunQuery(sSql);
            dgvHopDong.DataSource = dtHopDong;
        }
        private void SetControls(bool edit)
        {
            //đặt trạng thái các textBox
            cboTenPhong.Enabled = edit;
            cboSoDT.Enabled = edit;
            txtGiaPhong.Enabled = edit;
            txtKhachThue.Enabled = edit;
            txtDatCoc.Enabled = edit;
            txtDonGiaDien.Enabled = edit;
            txtDonGiaNuoc.Enabled = edit;
            txtTienMang.Enabled = edit;
            rbDaKT.Enabled = edit;
            rbChuaKT.Enabled = edit;
            //đặt trạng thái các nút ấn
            btnThemmoi.Enabled = !edit;
            btnSua.Enabled = !edit;
            btnXoa.Enabled = !edit;
            btnLuu.Enabled = edit;
            btnHuy.Enabled = edit;
        }

        private void dgvHopDong_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            string sSql;
            //hiển thị tên loại sách trong cboTenPhong ứng với PhongID
            cboTenPhong.SelectedValue = dgvHopDong.Rows[e.RowIndex].Cells["IDPhong"].Value.ToString();
            cboSoDT.SelectedValue = dgvHopDong.Rows[e.RowIndex].Cells["IDKhachHang"].Value.ToString();
            //chuyển dữ liệu của dòng hiện thời sang lưới 
            txtGiaPhong.Text = double.Parse(dgvHopDong.Rows[e.RowIndex].Cells["GiaPhong"].Value.ToString()).ToString("N0");
            txtDatCoc.Text = double.Parse(dgvHopDong.Rows[e.RowIndex].Cells["DatCoc"].Value.ToString()).ToString("N0");
            txtDonGiaDien.Text = double.Parse(dgvHopDong.Rows[e.RowIndex].Cells["DonGiaDien"].Value.ToString()).ToString("N0");
            txtDonGiaNuoc.Text = double.Parse(dgvHopDong.Rows[e.RowIndex].Cells["DonGiaNuoc"].Value.ToString()).ToString("N0");
            txtTienMang.Text = double.Parse(dgvHopDong.Rows[e.RowIndex].Cells["TienMang"].Value.ToString()).ToString("N0");
            if (dgvHopDong.Rows[e.RowIndex].Cells["DaKetThuc"].Value.ToString().Trim() == "1")
                rbDaKT.Checked = true;
            else 
                rbChuaKT.Checked = true;

            // Hiển thị các tác giả
            string IDHopDong = dgvHopDong.Rows[e.RowIndex].Cells["IDHopDong"].Value.ToString();
            //Hien thi du lieu cua dgvKhachThue
             sSql = "Select * from tblHopDong a INNER JOIN " +
                "tblNguoiDung b ON a.IDKhachHang = b.IDKhachHang Where IDHopDong=" + IDHopDong;
            DataTable dtKhachThue = myDataServices.RunQuery(sSql);
            // ko hien thị thừa
            dgvKhachThue.AutoGenerateColumns = false;
            dgvKhachThue.DataSource = dtKhachThue;

            //hien thi phong còn trong
            sSql = "SELECT * FROM tblPhong where TrangThai = 0";
            DataTable dtPhong = myDataServices.RunQuery(sSql);
            dgvPhong.DataSource = dtPhong;

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            //kiem tra dữ liệu
            if (txtDatCoc.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập tiền cọc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDatCoc.Focus();
                return;
            }
            if (txtDonGiaDien.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập gái điện!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDonGiaDien.Focus();
                return;
            }
            if (txtDonGiaNuoc.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập giá nước", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDonGiaNuoc.Focus();
                return;
            }
            if (txtTienMang.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập tiền mạng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTienMang.Focus();
                return;
            }
        //
            //thêm mới hoặc sửa
            if (modeNew == true)
            {
                //thêm mới  Nhập dữ liệu vào bảng HopDong
                //1. tao 1 dòng dữ liệu mới
                DataRow myDataRow = dtHopDong.NewRow();
                //2. gán dữ liệu cho các cột
                myDataRow["IDPhong"] = cboTenPhong.SelectedValue; //lấy mã
                myDataRow["IDKhachHang"] = cboSoDT.SelectedValue;//
                myDataRow["GiaPhong"] = double.Parse(txtGiaPhong.Text);
                myDataRow["DatCoc"] = double.Parse(txtDatCoc.Text);
                myDataRow["DonGiaDien"] = double.Parse(txtDonGiaDien.Text);
                myDataRow["DonGiaNuoc"] = double.Parse(txtDonGiaNuoc.Text);
                myDataRow["TienMang"] = double.Parse(txtTienMang.Text);
                if (rbDaKT.Checked == true)
                    myDataRow["DaKetThuc"] = 1;
                else
                    myDataRow["DaKetThuc"] = 0;
                //1.1. thêm dòng dữ liệu vào dtHopDong
                dtHopDong.Rows.Add(myDataRow);
                //1.2. Cập nhật dữ liệu từ dtHopDong vào bảng HopDong trong CSDL
                myDataServices.Update(dtHopDong);

                
                // thông báo
                MessageBox.Show("Thêm phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //sửa dữ liệu
                //1. Lấy dòng cần sửa
                int r = dgvHopDong.CurrentRow.Index;
                //2. Lấy dữ liệu của dòng r trong dtKhachang
                DataRow myDataRow = dtHopDong.Rows[r];
                //3. Gán lại dữ liệu
                myDataRow["IDPhong"] = cboTenPhong.SelectedValue; //lấy mã
                myDataRow["IDKhachHang"] = cboSoDT.SelectedValue;//
                myDataRow["GiaPhong"] = double.Parse(txtGiaPhong.Text);
                myDataRow["DatCoc"] = double.Parse(txtDatCoc.Text);
                myDataRow["DonGiaDien"] = double.Parse(txtDonGiaDien.Text);
                myDataRow["DonGiaNuoc"] = double.Parse(txtDonGiaNuoc.Text);
                myDataRow["TienMang"] = double.Parse(txtTienMang.Text);
                if (rbDaKT.Checked == true)
                    myDataRow["DaKetThuc"] = 1;
                else
                    myDataRow["DaKetThuc"] = 0;
                //4. Cập nhật dữ liệu từ dtHopDong vào bảng HopDong trong CSDL
                myDataServices.Update(dtHopDong);

                // thong bao
                MessageBox.Show("Sửa phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //Hiển thị lại dữ liệu           
            Display();
            //thiết lập lại trạng thái
            SetControls(false);
        }

        private void cboTenPhong_SelectedIndexChanged(object sender, EventArgs e)
        {
            // text cheuyeen theo cboTenphong
            txtLoaiPhong.Text = dtPhong.Rows[cboTenPhong.SelectedIndex]["LoaiPhong"].ToString();
            txtGiaPhong.Text = double.Parse(dtPhong.Rows[cboTenPhong.SelectedIndex]["DonGia"].ToString()).ToString("N0");
        }
        private void cboSoDT_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtKhachThue.Text = dtKhach.Rows[cboSoDT.SelectedIndex]["HoTen"].ToString();
        }

        private void btnCTHD_Click(object sender, EventArgs e)
        {
            
            frmChiTietHD frmChiTietHD = new frmChiTietHD();
            frmChiTietHD.ShowDialog();
        }
        private void btnThemmoi_Click(object sender, EventArgs e)
        {
            modeNew = true;
            //xóa trắng các textbox
            //cboTenPhong.Clear();
            txtGiaPhong.Clear();
            txtKhachThue.Clear();
            txtDatCoc.Clear();
            txtDonGiaDien.Clear();
            txtDonGiaNuoc.Clear();
            txtTienMang.Clear();
            SetControls(true);
            //chuyển con trỏ về cboTenPhong
            cboTenPhong.Focus();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            modeNew = false;
            SetControls(true);
            //chuyển con trỏ về cboTenPhong
            cboTenPhong.Focus();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //xác nhận chắc chắn xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //1. lấy dòng đang chọn để xóa
            int r = dgvHopDong.CurrentRow.Index;
            //2. lấy HopDongID của dòng đang chọn
            string IDHopDong = dgvHopDong.Rows[r].Cells[0].Value.ToString();
            //3. xóa dữ liệu trong bảng HopDong
            dtHopDong.Rows[r].Delete();
            myDataServices.Update(dtHopDong);

            MessageBox.Show("Xóa phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            SetControls(false);
        }

        
    }
}
