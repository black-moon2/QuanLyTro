﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanliphongtro
{
    public partial class frmKH : Form
    {
        //khai báo đối tượng lớp dịch vụ dữ liệu
        private DataServices myDataServices;
        //khai báo biến để lưu bản sao của bảng dữ liệu tblKhacHang
        private DataTable dtKhachHang;
        //khai báo biến để kiểm tra đã chọn nút thêm mới hay sửa
        private bool modeNew;
        //khai báo biến để lưu số dt - kiểm tra trùng
        private string oldDienThoai;
        //khai báo biến để lưu Chứng minh nd - cho kiểm tra tài khoản trùng
        private string _CMND;
        public frmKH()
        {
            InitializeComponent();
        }

        private void frmKH_Load(object sender, EventArgs e)
        {
            //truy vấn dữ liệu
            Display();
            //gọi hàm thiết lập các điều khiển
            SetControls(false);
        }
        //hàm truy vấn dữ liệu
        private void Display()
        {
            string sSql = "SELECT * FROM tblNguoiDung Order By IDKhachHang";
            myDataServices = new DataServices();
            dtKhachHang = myDataServices.RunQuery(sSql);
            //hiển thị lên lưới
            dgvKhachHang.DataSource = dtKhachHang;
        }
        //hàm thay đổi trạng thái các nút ấn
        private void SetControls(bool edit)
        {
            //đặt trạng thái các textBox
            txtHoTen.Enabled = edit;
            txtCMND.Enabled = edit;
            txtGioiTinh.Enabled = edit;
            txtDienThoai.Enabled = edit;
            txtQueQuan.Enabled = edit;
            txtHKTT.Enabled = edit;

            //đặt trạng thái các nút ấn
            btnThemMoi.Enabled = !edit;
            btnSua.Enabled = !edit;
            btnXoa.Enabled = !edit;
            btnLuu.Enabled = edit;
            btnHuy.Enabled = edit;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            
            //kiểm tra dữ liệu trùng CMND
            if ((modeNew == true) || ((modeNew == false) && (txtCMND.Text.ToUpper() != _CMND.ToUpper())))
            {
                //truy vấn dữ liệu để kiểm tra trùng
                string sSql = "SELECT CMND from tblNguoiDung WHERE CMND = N'" + txtCMND.Text + "'";
                DataServices myDataServices1 = new DataServices();
                DataTable dtSearch = myDataServices1.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã trùng Chứng Minh Nhân Dân!", "Thông báo", MessageBoxButtons.OK);
                    txtCMND.Focus();
                    return;
                }
             }
            //kiểm tra trùng số Phone
            if ((modeNew == true) || ((modeNew == false) && (txtDienThoai.Text.ToUpper() != oldDienThoai.ToUpper())))
            {
                //truy vấn dữ liệu để kiểm tra trùng
                string sSql = "SELECT DienThoai from tblNguoiDung WHERE DienThoai = N'" + txtDienThoai.Text + "'";
                DataServices myDataServices1 = new DataServices();
                DataTable dtSearch = myDataServices1.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã trùng số điện thoại!", "Thông báo", MessageBoxButtons.OK);
                    txtDienThoai.Focus();
                    return;
                }
            }
            //------------
            //kiem tra dữ liệu
            if (txtHoTen.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập họ và tên khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtHoTen.Focus();
                return;
            }
            if (txtCMND.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập số CCCD của khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCMND.Focus();
                return;
            }
            if (txtGioiTinh.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập giới tính của khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtGioiTinh.Focus();
                return;
            }
            if (txtDienThoai.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập số điện thoại của khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDienThoai.Focus();
                return;
            }
            if (txtQueQuan.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập quê quán của khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtQueQuan.Focus();
                return;
            }
            //câp nhật
            if (modeNew == true)
            {
                //them moi
                //1. tao 1 dòng dữ liệu mới
                DataRow myDataRow = dtKhachHang.NewRow();
                //2. gán dữ liệu cho các cột
                myDataRow["HoTen"] = txtHoTen.Text;
                myDataRow["CMND"] = txtCMND.Text;
                myDataRow["GioiTinh"] = txtGioiTinh.Text;
                myDataRow["DienThoai"] = txtDienThoai.Text;
                myDataRow["QueQuan"] = txtQueQuan.Text;
                myDataRow["HKTT"] = txtHKTT.Text;
                //3. thêm dòng dữ liệu vào dtKhachHang
                dtKhachHang.Rows.Add(myDataRow);
                //4. Cập nhật dữ liệu từ dtKhachHang vào bảng KhachHang trong CSDL
                myDataServices.Update(dtKhachHang);
                // thông báo
                MessageBox.Show("Thêm phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //sửa dữ liệu
                //1. Lấy dòng cần sửa
                int r = dgvKhachHang.CurrentRow.Index;
                //2. Lấy dữ liệu của dòng r trong dtKhachang
                DataRow myDataRow = dtKhachHang.Rows[r];
                //3. Gán lại dữ liệu
                myDataRow["HoTen"] = txtHoTen.Text;
                myDataRow["CMND"] = txtCMND.Text;
                myDataRow["GioiTinh"] = txtGioiTinh.Text;
                myDataRow["DienThoai"] = txtDienThoai.Text;
                myDataRow["QueQuan"] = txtQueQuan.Text;
                myDataRow["HKTT"] = txtHKTT.Text;
                //4. Cập nhật dữ liệu từ dtKhachHang vào bảng KhachHang trong CSDL
                myDataServices.Update(dtKhachHang);
                MessageBox.Show("Sửa phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //Hiển thị lại dữ liệu           
            Display();
            //thiết lập lại trạng thái
            SetControls(false);
        }

        private void dgvKhachHang_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtHoTen.Text = dgvKhachHang.Rows[e.RowIndex].Cells["HoTen"].Value.ToString();
            txtCMND.Text = dgvKhachHang.Rows[e.RowIndex].Cells["CMND"].Value.ToString();
            txtGioiTinh.Text = dgvKhachHang.Rows[e.RowIndex].Cells["GioiTinh"].Value.ToString();
            txtDienThoai.Text = dgvKhachHang.Rows[e.RowIndex].Cells["DienThoai"].Value.ToString();
            txtQueQuan.Text = dgvKhachHang.Rows[e.RowIndex].Cells["QueQuan"].Value.ToString();
            txtHKTT.Text = dgvKhachHang.Rows[e.RowIndex].Cells["HKTT"].Value.ToString();

            //luu lại cmnd , dien thoai, tài kkhoan
            _CMND = txtCMND.Text;
            oldDienThoai = txtDienThoai.Text;
        }
  
        private void btnThemMoi_Click(object sender, EventArgs e)
        {
            modeNew = true;
            SetControls(true);
            //xóa trắng các textbox
            txtHoTen.Clear();
            txtCMND.Clear();
            txtGioiTinh.Clear();
            txtDienThoai.Clear();
            txtQueQuan.Clear();
            txtHKTT.Clear();
            //chuyển con trỏ về txtFullName
            txtHoTen.Focus();
        }
        private void btnSua_Click(object sender, EventArgs e)
        {
            modeNew = false;
            SetControls(true);
            txtHoTen.Focus();
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            //xác nhận chắc chắn xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;
            //1. lấy dòng đang chọn để xóa
            int r = dgvKhachHang.CurrentRow.Index;
            //2. xóa dòng tương ứng với r trong dtKhachHang
            dtKhachHang.Rows[r].Delete();
            //3. Cập nhật lại bảng KhachHang trong CSDL
            myDataServices.Update(dtKhachHang);
            MessageBox.Show("Xóa phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void btnHuy_Click(object sender, EventArgs e)
        {
            SetControls(false);
        }
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            //truy vấn dữ liệu
            string sSql;
            if (rbSoDT.Checked == true)
            {
                sSql = "SELECT * FROM tblNguoiDung WHERE (DienThoai LIKE N'%" + txtTimKiem.Text + "%')";
            }
            else
            {
                sSql = "SELECT * FROM tblNguoiDung WHERE (CMND LIKE N'%" + txtTimKiem.Text + "%')";
            }
            //Hiển thị lại dữ liệu
            dtKhachHang = myDataServices.RunQuery(sSql);
            //hiển thị lên lưới
            dgvKhachHang.DataSource = dtKhachHang;
        }
        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
