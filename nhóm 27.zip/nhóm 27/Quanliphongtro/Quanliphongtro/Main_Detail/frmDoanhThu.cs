﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanliphongtro.Main_Detail
{
    public partial class frmDoanhThu : Form
    {
        private DataServices myDataServices = new DataServices();
        private DataTable myTable;

        private double tienphong, tiennuoc, tiendien, tienmang, tongtienthang, sonothieu;

        public frmDoanhThu()
        {
            InitializeComponent();
        }

        private void frmDoanhThu_Load(object sender, EventArgs e)
        {
           
        }

        private void btnTongKet_Click(object sender, EventArgs e)
        {
            
            string sSql = "select SUM(HD.GiaPhong) as tienphong, SUM(HD.TienMang) as tienmang, SUM((CT.CSN_Moi-CT.CSN_Cu)*HD.DonGiaNuoc) as tiennuoc, SUM((CT.CSD_Moi-CT.CSD_Cu)*HD.DonGiaDien) as tiendien FROM tblChiTietHopDong CT " +
               "INNER JOIN tblHopDong HD ON CT.IDHopDong = HD.IDHopDong " +
               "WHERE CT.NgayBatDau >= '" + txtNgayBatDau.Text + "' and CT.NgayBatDau <= '" + txtNgayKetThuc.Text + "'";
            myTable = myDataServices.RunQuery(sSql);
            try
            {
                tienphong = double.Parse(lbTienPhong.Text = myTable.Rows[0]["tienphong"].ToString());
                tienmang = double.Parse(lbTienMang.Text = myTable.Rows[0]["tienmang"].ToString());
                tiennuoc = double.Parse(lbTienNuoc.Text = myTable.Rows[0]["tiennuoc"].ToString());
                tiendien = double.Parse(lbTienDien.Text = myTable.Rows[0]["tiendien"].ToString());
                
            }
            catch (Exception loi)
            {
                // khối này thực thi khi bắt được lỗi
                Console.WriteLine("Có lỗi rồi");
                Console.WriteLine(loi.Message);
            }
            tongtienthang = (tienphong + tienmang + tiennuoc + tiendien);
            lbTongTien.Text = tongtienthang.ToString();
            
        }
    }
}
