﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanliphongtro.Main_Detail
{
    public partial class frmChiTietHD : Form
    {
        //khai báo đối tượng lớp dịch vụ dữ liệu
        private DataServices DataServices;
        //khai báo biến để lưu bản sao của bảng dữ liệu
        private DataTable dtCTHD;
        //khai báo biến để lưu IDHopDong - kiểm tra trùng
        private string oldHopDong;
        //khai báo biến để kiểm tra đã chọn nút thêm mới hay sửa
        private bool modeNew;

        public frmChiTietHD()
        {
            InitializeComponent();
        }
        
        private void frmChiTietHD_Load(object sender, EventArgs e)
        {
            //thiết lập các điều khiển
            SetControls(false);
            //Hiển thị dữ liệu
            Display();
            
        }
        //hàm truy vấn dữ liệu
        private void Display()
        {
            string sSql = "SELECT * FROM tblChiTietHopDong Order By IDCTHD";
            DataServices = new DataServices();
            dtCTHD = DataServices.RunQuery(sSql);
            //hiển thị lên lưới
            dgvHopDong.DataSource = dtCTHD;
            
            
        }
        private void SetControls(bool edit)
        {
            //đặt trạng thái các textBox
            txtIDHopDong.Enabled = edit;
            txtNgayBatDau.Enabled = edit;
            txtNgayKetThuc.Enabled = edit;
            txtDienMoi.Enabled = edit;
            txtDienCu.Enabled = edit;
            txtNuocMoi.Enabled = edit;
            txtNuocCu.Enabled = edit;
            //đặt trạng thái các nút ấn
            btnThem.Enabled = !edit;
            btnSua.Enabled = !edit;
            btnXoa.Enabled = !edit;
            btnLuu.Enabled = edit;
            btnHuy.Enabled = edit;
        }

        private void dgvHopDong_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtIDHopDong.Text = dgvHopDong.Rows[e.RowIndex].Cells["IDHopDong"].Value.ToString();
            txtNgayBatDau.Text = dgvHopDong.Rows[e.RowIndex].Cells["NgayBatDau"].Value.ToString();
            txtNgayKetThuc.Text = dgvHopDong.Rows[e.RowIndex].Cells["NgayKetThuc"].Value.ToString();
            txtDienCu.Text = dgvHopDong.Rows[e.RowIndex].Cells["CSD_Cu"].Value.ToString();
            txtDienMoi.Text = dgvHopDong.Rows[e.RowIndex].Cells["CSD_Moi"].Value.ToString();
            txtNuocCu.Text = dgvHopDong.Rows[e.RowIndex].Cells["CSN_Cu"].Value.ToString();
            txtNuocMoi.Text = dgvHopDong.Rows[e.RowIndex].Cells["CSN_Moi"].Value.ToString();
            // luu id hop dong
            oldHopDong = txtIDHopDong.Text;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            string sSql;
            //kiểm tra dữ liệu trùng
            if ((modeNew == true) || ((modeNew == false) && (txtIDHopDong.Text.ToUpper() != oldHopDong.ToUpper())))
            {
                //truy vấn dữ liệu để kiểm tra trùng
                sSql = "SELECT TenPhong from tblPhong WHERE TenPhong = N'" + txtIDHopDong.Text + "'";
                DataServices myDataServices1 = new DataServices();
                DataTable dtSearch = myDataServices1.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã trùng ID hợp đồng, xin vui lòng nhập lại!", "Thông báo", MessageBoxButtons.OK);
                    txtIDHopDong.Focus();
                    return;
                }
            }
            //kiem tra dữ liệu
            if (txtIDHopDong.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập ID Hợp Đồng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtIDHopDong.Focus();
                return;
            }
            if (txtNgayBatDau.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập họ ngày bắt đầu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNgayBatDau.Focus();
                return;
            }
            if (txtNgayKetThuc.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập họ ngày kết thúc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNgayKetThuc.Focus();
                return;
            }
            if (txtDienCu.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập điện cũ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDienCu.Focus();
                return;
            }
            if (txtDienMoi.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập điện mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDienMoi.Focus();
                return;
            }
            if (txtNuocCu.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập nước cũ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNuocCu.Focus();
                return;
            }
            if (txtNuocMoi.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập nước mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNuocMoi.Focus();
                return;
            }
            //câp nhật
            if (modeNew == true)
            {
                //them moi
                //1. tao 1 dòng dữ liệu mới
                DataRow myDataRow = dtCTHD.NewRow();
                //2. gán dữ liệu cho các cột
                myDataRow["IDHopDong"] = txtIDHopDong.Text;
                myDataRow["NgayBatDau"] = txtNgayBatDau.Text;
                myDataRow["NgayKetThuc"] = txtNgayKetThuc.Text;
                myDataRow["CSD_Cu"] = txtDienCu.Text;
                myDataRow["CSD_Moi"] = txtDienMoi.Text;
                myDataRow["CSN_Cu"] = txtNuocCu.Text;
                myDataRow["CSN_Moi"] = txtNuocMoi.Text;
                //3. thêm dòng dữ liệu vào dtcthd
                dtCTHD.Rows.Add(myDataRow);
                //4. Cập nhật dữ liệu từ dtcthd vào bảng chitiethd trong CSDL
                DataServices.Update(dtCTHD);
                MessageBox.Show("Thêm phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //sửa dữ liệu
                //1. Lấy dòng cần sửa
                int r = dgvHopDong.CurrentRow.Index;
                //2. Lấy dữ liệu của dòng r trong dt
                DataRow myDataRow = dtCTHD.Rows[r];
                //3. Gán lại dữ liệu
                myDataRow["IDHopDong"] = txtIDHopDong.Text;
                myDataRow["NgayBatDau"] = txtNgayBatDau.Text;
                myDataRow["NgayKetThuc"] = txtNgayKetThuc.Text;
                myDataRow["CSD_Cu"] = txtDienCu.Text;
                myDataRow["CSD_Moi"] = txtDienMoi.Text;
                myDataRow["CSN_Cu"] = txtNuocCu.Text;
                myDataRow["CSN_Moi"] = txtNuocMoi.Text;
                //4. Cập nhật dữ liệu từ dtKhachHang vào bảng KhachHang trong CSDL
                DataServices.Update(dtCTHD);
                MessageBox.Show("Sửa phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //Hiển thị lại dữ liệu           
            Display();
            //thiết lập lại trạng thái
            SetControls(false);
        }
        private void btnSua_Click(object sender, EventArgs e)
        {
            modeNew = false;
            SetControls(true);
            //chuyển con trỏ về cboTenPhong
            txtIDHopDong.Focus();
        }
        private void btnHuy_Click(object sender, EventArgs e)
        {
            SetControls(false);
        }
        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            modeNew = true;
            SetControls(true);
            //xóa trắng các textbox
            txtIDHopDong.Clear();
            txtNgayBatDau.Clear();
            txtNgayKetThuc.Clear();
            txtDienMoi.Clear();
            txtDienCu.Clear();
            txtNuocCu.Clear();
            txtNuocMoi.Clear();

            //chuyển con trỏ về txtFullName
            txtIDHopDong.Focus();
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            //xác nhận chắc chắn xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;
            //1. lấy dòng đang chọn để xóa
            int r = dgvHopDong.CurrentRow.Index;
            //2. xóa dòng tương ứng với r trong dtKhachHang
            dtCTHD.Rows[r].Delete();
            //3. Cập nhật lại bảng KhachHang trong CSDL
            DataServices.Update(dtCTHD);
            MessageBox.Show("Xóa phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
