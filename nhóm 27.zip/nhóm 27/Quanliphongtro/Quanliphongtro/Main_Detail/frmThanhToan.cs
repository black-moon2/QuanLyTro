﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace Quanliphongtro.Main_Detail
{
    public partial class frmThanhToan : Form
    {
        DataTable dtPhong;
        //khai báo đối tượng lớp dịch vụ dữ liệu
        private DataServices myDataServices = new DataServices();
        private DataTable myTable;
       
        private double tienphong, tiennuoc, tiendien, tienmang, tongtienthang, sotiendatra, sonothieu;

        private void btnHuy_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            //thêm mới dữ liệu
            //1. tao 1 dòng dữ liệu mới
            DataRow addRow = dtPhong.NewRow();
            //2. gán dữ liệu cho các cột
            addRow["ThanhToan"] = txtThanhToan.Text;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            txtPhong.Text = cboTenPhong.GetItemText(cboTenPhong.SelectedItem).ToString();
            string sSql = "SELECT ND.HoTen, HD.GiaPhong, HD.TienMang FROM tblHopDong HD " +
              "INNER JOIN tblPhong P ON HD.IDPhong = P.IDPhong " +
              "INNER JOIN tblChiTietHopDong CT ON HD.IDHopDong = CT.IDHopDong " +
              "INNER JOIN tblNguoiDung ND ON HD.IDKhachHang = ND.IDKhachHang " +
              "WHERE P.TenPhong = N'" + txtPhong.Text + "'";
            myTable = myDataServices.RunQuery(sSql);
            if (myTable.Rows.Count > 0)
            {
                lbHoTen.Text = myTable.Rows[0]["HoTen"].ToString();
                tienphong = double.Parse(lbTienPhong.Text = myTable.Rows[0]["GiaPhong"].ToString());
                tienmang = double.Parse(lbTienMang.Text = myTable.Rows[0]["TienMang"].ToString());
            }
            //tiendien,tiennuoc, 
            Tinh_Toan1();
            //
             ThanhToan();

        }

        private void cboTenPhong_SelectionChangeCommitted(object sender, EventArgs e)
        {
            txtPhong.Text = cboTenPhong.GetItemText(cboTenPhong.SelectedItem).ToString();
        }


        public frmThanhToan()
        {
            InitializeComponent();
        }

        private void frmThanhToan_Load(object sender, EventArgs e)
        {

            //1. chuyển dữ liệu vào cboTenPhong
            string sSql = "Select P.IDPhong, P.TenPhong from tblPhong P " +
                         "inner join tblHopDong H on H.IDPhong=P.IDPhong ";
            dtPhong = myDataServices.RunQuery(sSql);
            cboTenPhong.DataSource = dtPhong;
            cboTenPhong.DisplayMember = "TenPhong";
            cboTenPhong.ValueMember = "IDPhong";
            
        }
        
        private void Tinh_Toan1()
        {
            string sSql = "select SUM((CT.CSN_Moi-CT.CSN_Cu)*HD.DonGiaNuoc) as tiennuoc, SUM((CT.CSD_Moi-CT.CSD_Cu)*HD.DonGiaDien) as tiendien, SUM(CT.ThanhToan) as tientra FROM tblChiTietHopDong CT " +
               "INNER JOIN tblHopDong HD ON CT.IDHopDong = HD.IDHopDong " +
               "INNER JOIN tblPhong P ON HD.IDPhong = P.IDPhong " +
               "WHERE P.TenPhong = N'" + txtPhong.Text + "'";
            myTable = myDataServices.RunQuery(sSql);
            try
            {
                tiennuoc = double.Parse(lbTienNuoc.Text = myTable.Rows[0]["tiennuoc"].ToString());
                tiendien = double.Parse(lbTienDien.Text = myTable.Rows[0]["tiendien"].ToString());
                sotiendatra = double.Parse(lbDaTra.Text = myTable.Rows[0]["tientra"].ToString());
            }
            catch (Exception loi)
            {
                // khối này thực thi khi bắt được lỗi
                lbDaTra.Text = "Chưa trả xu mô";
                Console.WriteLine("Có lỗi rồi");
                Console.WriteLine(loi.Message);
            }
        }
        private void ThanhToan()
        {
            tongtienthang = (tienphong + tienmang + tiennuoc + tiendien);
            lbTienCuaThang.Text = tongtienthang.ToString();
            sonothieu = (tongtienthang - sotiendatra);
            lbTienNo.Text = sonothieu.ToString();
        }

    }
}
