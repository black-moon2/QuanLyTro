﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Quanliphongtro
{
    public partial class frmPhong : Form
    {
        //khai báo đối tượng lớp dịch vụ dữ liệu
        private DataServices myDataServices;
        //khai báo biến để lưu bản sao của bảng dữ liệu tblPhong
        private DataTable dtPhong;
        //khai báo biến để kiểm tra đã chọn nút thêm mới hay sửa
        private bool modeNew;
        //khai báo biến để lưu tên phòng trọ - kiểm tra trùng
        private string oldTenPhong;
        public frmPhong()
        {
            InitializeComponent();
        }

        private void frmPhong_Load(object sender, EventArgs e)
        {
            //truy vấn dữ liệu
            Display();
            //gọi hàm thiết lập các điều khiển
            SetControls(false);
        }
        //hàm truy vấn dữ liệu
        private void Display()
        {
            string sSql = "SELECT * FROM tblPhong Order By IDPhong";
            myDataServices = new DataServices();
            dtPhong = myDataServices.RunQuery(sSql);
            //hiển thị lên lưới
            dgvPhong.DataSource = dtPhong;
        }
        private void SetControls(bool edit)
        {
            //đặt trạng thái các textBox
            txtTenPhong.Enabled = edit;
            txtLoaiPhong.Enabled = edit;
            txtDonGia.Enabled = edit;
            txtDienTich.Enabled = edit;
            txtSLTD.Enabled = edit;
            txtGhiChu.Enabled = edit;
            rbDay.Enabled = edit;
            rbTrong.Enabled = edit;
            //đặt trạng thái các nút ấn
            btnThemMoi.Enabled = !edit;
            btnSua.Enabled = !edit;
            btnXoa.Enabled = !edit;
            btnLuu.Enabled = edit;
            btnHuy.Enabled = edit;
        }
        private void dgvPhong_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //chuyển dữ liệu của dòng hiện thời sang lưới
            txtTenPhong.Text = dgvPhong.Rows[e.RowIndex].Cells["TenPhong"].Value.ToString();
            txtLoaiPhong.Text = dgvPhong.Rows[e.RowIndex].Cells["LoaiPhong"].Value.ToString();
            txtDonGia.Text = double.Parse(dgvPhong.Rows[e.RowIndex].Cells["DonGia"].Value.ToString()).ToString("N0");
            txtDienTich.Text = dgvPhong.Rows[e.RowIndex].Cells["DienTich"].Value.ToString();
            txtSLTD.Text = dgvPhong.Rows[e.RowIndex].Cells["SLToiDa"].Value.ToString();
            txtGhiChu.Text = dgvPhong.Rows[e.RowIndex].Cells["GhiChu"].Value.ToString();
            if (dgvPhong.Rows[e.RowIndex].Cells["TrangThai"].Value.ToString().Trim() == "1")
                rbDay.Checked = true;
            else
                rbTrong.Checked = true;
            // luu tên phong trọ
            oldTenPhong = txtTenPhong.Text;
        }
        private void btnLuu_Click(object sender, EventArgs e)
        {
            string sSql;
            //kiểm tra dữ liệu trùng
            if ((modeNew == true) || ((modeNew == false) && (txtTenPhong.Text.ToUpper() != oldTenPhong.ToUpper())))
            {
                //truy vấn dữ liệu để kiểm tra trùng
                sSql = "SELECT TenPhong from tblPhong WHERE TenPhong = N'" + txtTenPhong.Text + "'";
                DataServices myDataServices1 = new DataServices();
                DataTable dtSearch = myDataServices1.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã trùng tên phòng trọ, xin vui lòng nhập lại!", "Thông báo", MessageBoxButtons.OK);
                    txtTenPhong.Focus();
                    return;
                }
            }
            //kiem tra dữ liệu
            if (txtTenPhong.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập tên phòng trọ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTenPhong.Focus();
                return;
            }
            if (txtLoaiPhong.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập tên loại trọ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtLoaiPhong.Focus();
                return;
            }
            if (txtDonGia.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập số tiền thuê phòng trọ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDonGia.Focus();
                return;
            }
            if (txtSLTD.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập số lường người tối đa của phòng trọ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSLTD.Focus();
                return;
            }
            if (txtDienTich.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập diện tích của phòng trọ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSLTD.Focus();
                return;
            }

            //thêm mới hoặc sửa
            if (modeNew == true)
            {
                //thêm mới dữ liệu
                //1. tao 1 dòng dữ liệu mới
                DataRow addRow = dtPhong.NewRow();
                //2. gán dữ liệu cho các cột
                addRow["TenPhong"] = txtTenPhong.Text;
                addRow["LoaiPhong"] = txtLoaiPhong.Text;
                addRow["DonGia"] = double.Parse(txtDonGia.Text);
                addRow["DienTich"] = txtDienTich.Text;
                addRow["SLToiDa"] = txtSLTD.Text;
                addRow["GhiChu"] = txtGhiChu.Text;
                if (rbDay.Checked == true)
                    addRow["TrangThai"] = 1;
                else
                    addRow["TrangThai"] = 0;
                //3. thêm dòng dữ liệu vào dtPhong
                dtPhong.Rows.Add(addRow);
                //4. Cập nhật dữ liệu từ dtPhong vào bảng Phong trong CSDL
                myDataServices.Update(dtPhong);
                MessageBox.Show("Thêm mới phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //sửa dữ liệu
                //lấy dòng cần sửa
                int r = dgvPhong.CurrentRow.Index;
                //2. Lấy dữ liệu của dòng r trong dtCustomer
                DataRow addRow = dtPhong.Rows[r];
                //3. Gán lại dữ liệu
                addRow["TenPhong"] = txtTenPhong.Text;
                addRow["LoaiPhong"] = txtLoaiPhong.Text;
                addRow["DonGia"] = double.Parse(txtDonGia.Text);
                addRow["DienTich"] = txtDienTich.Text;
                addRow["SLToiDa"] = txtSLTD.Text;
                addRow["GhiChu"] = txtGhiChu.Text;
                if (rbDay.Checked == true)
                    addRow["TrangThai"] = 1;
                else
                    addRow["TrangThai"] = 0;
                //4. Cập nhật dữ liệu từ dtPhong vào bảng Phong trong CSDL
                myDataServices.Update(dtPhong);
                MessageBox.Show("Sửa phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //Hiển thị lại dữ liệu           
            Display();
            //thiết lập lại trạng thái
            SetControls(false);
        }

        private void btnThemMoi_Click(object sender, EventArgs e)
        {
            modeNew = true;
            SetControls(true);
            //xóa trắng các textbox
            txtTenPhong.Clear();
            txtLoaiPhong.Clear();
            txtDonGia.Clear();
            txtDienTich.Clear();
            txtSLTD.Clear();
            txtGhiChu.Clear();
            //chuyển con trỏ về txtFullName
            txtTenPhong.Focus();
        }
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            //truy vấn dữ liệu
            string sSql;
            if (rbTenPhong.Checked == true)
            {
                sSql = "SELECT * FROM tblPhong WHERE (TenPhong LIKE N'%" + txtTimKiem.Text + "%')";
            }
            else
            {
                sSql = "SELECT * FROM tblPhong WHERE (LoaiPhong LIKE N'%" + txtTimKiem.Text + "%')";
            }
            //Hiển thị lại dữ liệu
            dtPhong = myDataServices.RunQuery(sSql);
            //hiển thị lên lưới
            dgvPhong.DataSource = dtPhong;
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            //xác nhận chắc chắn xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //1. lấy dòng đang chọn để xóa
            int r = dgvPhong.CurrentRow.Index;
            //2. xóa dòng tương ứng với r trong dtPhong
            dtPhong.Rows[r].Delete();
            //3. Cập nhật lại bảng Phong trong CSDL
            myDataServices.Update(dtPhong);
            MessageBox.Show("Xóa phòng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void btnSua_Click(object sender, EventArgs e)
        {
            modeNew = false;
            SetControls(true);
            txtTenPhong.Focus();
        }
        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btnHuy_Click(object sender, EventArgs e)
        {
            SetControls(false);
        }
    }
}
